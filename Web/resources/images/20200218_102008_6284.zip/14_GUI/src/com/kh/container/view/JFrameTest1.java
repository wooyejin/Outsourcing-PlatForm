package com.kh.container.view;

import java.awt.Color;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

public class JFrameTest1 extends JFrame{
	/* 컨테이너 :
	 * 		화면에 표시하고자 하는 요소(컴포넌트)들을 
	 * 		담을 수 있는 객체를 컨테이너라고 한다.
	 * 		대표적으로 JFrame 객체가 해당하며
	 * 		Panel/JPanel 객체가 있다. 
	 */
	
	// 컨테이너인 Frame을 생성하느느 방법1
	// JFrame을 상속받아 사용하는 방법
	// javax.swing.JFrame 클래스를 상속받은 후에
	// 해당 프레임에 크기, 열리는 위치를 설정하여 생정자를 통해 실행하면된다.
	
	public JFrameTest1() {
		// 프레임의 크기 설정하기
		this.setSize(400,200);
		
		// 프레임이 시작되는 위치 설정하기
		this.setLocation(300, 300);
		
		// 프레임의 위치와 크기를 한번에 설정하기
		//		int x, int y, int width, int height
		this.setBounds(200,100,500,400);
		
		// 프레임 최상단에 제목 짓기
		this.setTitle("My JFrame");
		
		// 프레임에 사이즈를 변경하기 못하게 막기
		// 기본값 : true
		this.setResizable(false);
		
		// 프레임을 종료하더라도, 실제 프로그램이 종료되지 않을 때
		// 닫기버튼(X)을 클릭했을 때 강제로 프로그램 자체를 종료하게 하는 설정
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// 프레임에서 내가 원하는 아이콘 설정하기
		try {
			this.setIconImage(ImageIO.read(new File("Images/icon.png")));
		} catch (IOException e) {
			System.out.println("이미지 파일 오류 발생!");
		}
		
		
		// 구성한 프레임을 화면에 표시하기 위한  visible 설정 메소드 
		// 							(true : 보여주겠다.)
		this.setVisible(true);
	}
	
	
	
	
	
	
	
	

}
