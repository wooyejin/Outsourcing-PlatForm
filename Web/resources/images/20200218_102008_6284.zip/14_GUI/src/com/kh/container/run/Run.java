package com.kh.container.run;

import com.kh.container.view.JFrameTest1;
import com.kh.container.view.JFrameTest2;

public class Run {
	public static void main(String[] args) {
		//JFrameTest1 jt = new JFrameTest1();
		new JFrameTest2().showJFrame();
	}
}
