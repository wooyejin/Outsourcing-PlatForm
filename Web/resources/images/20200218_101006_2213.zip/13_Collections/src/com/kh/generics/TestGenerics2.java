package com.kh.generics;

import java.util.ArrayList;
import java.util.List;

public class TestGenerics2 {
	public static void main(String[] args) {
		

	// 책만 담기위한 ArrayList 생성
	ArrayList<Book> list1 = new ArrayList<Book>();
	// Car만 담기위한 ArrayList 생성
	ArrayList<Car> list2 = new ArrayList<Car>();
	
	list1.add(new Book("1"));
	list1.add(new Book("2"));
	list1.add(new Book("3"));
	list1.add(new Book("4"));
	list1.add(new Book("5"));
	
	list2.add(new Car("벤츠"));
	list2.add(new Car("람보르기니"));
	list2.add(new Car("아우디"));
	list2.add(new Car("포르쉐"));
	list2.add(new Car("제규어"));
	
	TestGenerics2 test = new TestGenerics2();
	test.printBook(list1);
	System.out.println("---------------");
	test.printCar(list2);
	}
	
	public void printBook(List<Book> list) {
		for(Book bk : list) {
			System.out.println(bk);
		}
	}
	public void printCar(List<Car> list) {
		for(Car c : list) {
			System.out.println(c);
		}
	}

}
