package com.kh.map;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

/*
 * Properties :
 * 		어떠한 프로그램을 실행할 때 함께 읽어오는 설정들 (언어설정, 옵션, DB연결정보 등)을 
 * 		저장하는 파일을 말한다.
 *		최근에는 XML방식으로 대체되었으나, 아직 많은 응용프로그램들이 이 파일을 설정파일로써
 *		사용하고있다.
 *		Properties는 Key와 Value로 이루어진 Map형식을 가지고있다.
 *		Key와  Value 모두는 문자열 형태로 저장하여 사용한다.
 *
 *		Serializable을 상속받은 HashTable을 상속받았기 때문에
 *		Stream으로 부터 입출력이 가능하여, 데이터를 파일로부터 쉽게 읽고, 쓰는 기능을 제공한다.
 * 
 */

public class TestProperties {
	public static void main(String[] args) {
		Properties prop = new Properties();
		
		// 값을 저장할때에는 setProperty() 메소드를 사용
		prop.setProperty("driver", "oracle.jdbc.driver.OracleDriver");
		prop.setProperty("url","jdbc:oracle:thin:@localhost:1521:XE");
		prop.setProperty("username","student");
		prop.setProperty("password", "student");
		
		System.out.println(prop);
		
		try {
			prop.store(new FileOutputStream("driver.dat"), "jdbc driver");
			prop.store(new FileOutputStream("driver.txt"), "jdbc driver");
			prop.storeToXML(new FileOutputStream("driver.xml"), "jdbc driver");
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}
		
	}
}
