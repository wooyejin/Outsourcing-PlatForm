package com.kh.list;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/*
 * Collection - List, Set
 * 		List 계열 : 순서를 유지하고 저장, 중복 저장 가능(ArrayList,Vector,LinkedList)
 * 		Set 계열 : 순서를 유지하지 않고 저장, 중복 저장 안됨(HashSet, TreeSet)
 * Map - 키와값의 쌍으로 저장, 키는 중복 저장안됨(HashMap,HashTable,TreeMap, Properties)
 */
public class TestList {
	/*
	 * List : 
	 * 		자료 구조 중 순서가 유지되고,
	 * 	 	중복이 허용되는 자료 구조 기법을 이야기하며,
	 *      자바에서는 ArrayList,Vector, LinkedList 등이 있다.
	 *      ArrayList와 Vector는 기능이 동일하나 ArrayList에는 Thread Safe(동시 제어)기능이 
	 *      없는 클래스이다. 
	 */
	
	public static void main(String[] args) {
		// ArrayList 테스트
		ArrayList alist = new ArrayList();
		
		// 다형성을 적용
		List blist = new ArrayList();
		
		// List를 포함한 Collection 객체들은 여러 자료형을 하나에 담을 수 있다.
		alist.add("사과");
		alist.add(12345); // 자동으로 래퍼클래스로 박싱처리된다.
		alist.add(true);
		alist.add(12.5);
		alist.add('A');
		
		// 1. 순서가 유지된다.
		// 2. toString()이 재정의(Override) 되어있다.
		System.out.println("alist :" + alist.toString());
		
		System.out.println("======================");
		// index(순번)를 기준으로
		// for문을 통해 반복할 수 있다.
		for(int i=0; i<alist.size(); i++) {
			System.out.println(i+" : "+ alist.get(i));
		}
		
		// 중복이 허용된다.
		alist.add("사과");
		System.out.println("alist :" + alist.toString());
		
		// 배열 중간에 값을 쉽게 추가할 수 있으며,
		// 추가할 때 해당 위치에 있던 값과 그 뒤의 값들이 한 칸씩 뒤로 밀려난다.
		alist.add(2,"추가합니다.");
		System.out.println("alist : "+ alist);
		
		// 배열 중간의 값을 쉽게 삭제할 수 있다.
		// 삭제할 경우  그 뒤의 값들이 한칸씩 앞으로 당겨진다.
		alist.remove(5);
		System.out.println("alist : " + alist);
		
		// 값의 변경 시 set() 메소드를 통해
		// 해당 위치의 값을 변경할 수 있다.
		alist.set(3, "귤");
		System.out.println("alist : " + alist);
		
		// 정렬 확인용 객체
		ArrayList sortList = new ArrayList();
		
		sortList.add("자동차");
		sortList.add("엘리베이터");
		sortList.add("안경");
		sortList.add("사과");
		sortList.add("카레라이스");
		
		System.out.println("sortList : " + sortList);
		// 오름차순 정렬
		Collections.sort(sortList);
		System.out.println("sortList : " + sortList);
		
		// 내림차순정렬
		Iterator iter
			= new LinkedList(sortList).descendingIterator();
		
		while(iter.hasNext()) {
			System.out.println(iter.next());
		}
	}
}











