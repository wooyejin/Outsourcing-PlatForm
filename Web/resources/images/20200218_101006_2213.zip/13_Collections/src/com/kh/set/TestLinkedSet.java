package com.kh.set;

import java.util.LinkedHashSet;
import java.util.Set;

public class TestLinkedSet {
	public static void main(String[] args) {
		// 각각의 요소를 링크로 연결하여(주소를 저장하여)
		// 순서를 형성하는 set 클래스
		Set lset = new LinkedHashSet();
		
		lset.add("사과");
		lset.add(12345);
		lset.add(true);
		lset.add(12.5);
		lset.add('A');
		lset.add('A');
		
		System.out.println("lset : " +lset);
		
		for(Object s : lset) {
			System.out.println(s);
		}
	}
}
