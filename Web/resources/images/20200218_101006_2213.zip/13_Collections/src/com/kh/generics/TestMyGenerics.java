package com.kh.generics;

public class TestMyGenerics {
	// 내가 만든 제한 자료형을 가진 MyGenerics 테스트
	public static void main(String[] args) {
		String[] arr = {"one","two","three","four","five"};
		
		MyGenerics<String> my1 = new MyGenerics<>(arr);
		
		my1.output();
		
		// 제네릭에 기본 자료형을 적용시키고자 한다면 --> 래퍼클래스로 박싱처리를 한후에 적용
		Integer[] iarr = {10,20,30,40,50};
		
		MyGenerics<Integer> my2 = new MyGenerics<>(iarr);
		my2.output();
	}
}
