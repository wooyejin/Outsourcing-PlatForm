package com.kh.list.sort;

import java.util.Comparator;

/*
 * Comparable : 
 * 		패키지       -> java.lang
 * 		사용메소드 -> compareTo()
 *  	정렬하고자 하는 객체에 comparable를 상속받아 compareTo()메소드를 오버라이딩해서 기존의
 *      정렬 기준 재정의 (한개의 정렬만 가능)
 * Comparator : 
 * 		패키지 -> java.util
 * 		사용메소드는 -> compare()
 * 		vo패키지 안에 필요한 정렬 기준에 맞춘 클래스들을 생성하고
 * 		Comparator를 상속받아 compare()메소드를 오버라이딩해서 기존의 정렬 기준 재정의
 * 		여러 개의 정렬 가능
 */
public class AscNameSort implements Comparator{
	
	@Override
	public int compare(Object o1, Object o2) {
		// Product 하나하나를 비교하기 위해
		// 각 객체를 가져온 뒤 해당 객체의 
		// name값을 비교하여 정렬하는 메소드
		Product p1 = (Product)o1;
		Product p2 = (Product)o2;
		
		// compareTo : int를 리턴하게 하고, 리턴되는 int값이 음수면 현재 인스턴스가
		//             비교대상인 인스턴스보다 작고, 양수이면 크고 0이면 같다
		return p1.getName().compareTo(p2.getName());
	}
	
}
