package com.kh.list.sort;

import java.util.ArrayList;

public class TestListSort {
	public static void main(String[] args) {
		
		ArrayList list = new ArrayList();
		list.add(new Product("PAV",500000,0.05));
		list.add(new Product("iPhone",700000,0.03));
		list.add(new Product("Gallaxy",800000,0.01));
		
		System.out.println("list : " + list);
		
		for(Object obj : list) {
			System.out.println(obj);
		}
		
		// product의 이름을 기준으로 오름차순
		System.out.println("=== product 이름으로 오름차순 ===");
		list.sort(new AscNameSort());
		
		for(Object obj : list) {
			System.out.println(obj);
		}
		
		System.out.println("=== product 이름으로 내림차순===");
		list.sort(new DescNameSort());
		
		for(Object obj : list) {
			System.out.println(obj);
		}
		
		System.out.println("=== product 가격으로 오름차순===");
		list.sort(new AscPriceSort());
		
		for(Object obj : list) {
			System.out.println(obj);
		}
		
		System.out.println("=== product 가격으로 내림차순===");
		list.sort(new DescPriceSort());
		
		for(Object obj : list) {
			System.out.println(obj);
		}
	}
}
