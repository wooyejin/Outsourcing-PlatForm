package com.kh.map;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class TestHashMap {
	// Map :
	//		데이터(자료)를 저장할 때
	// 		각각의 자료들을 구분짓는 고유의 값을 정하여
	// 		해당 값으로 접근하는 실체 객체를 구분지으려고 할 때 사용
	//		Key는 Set의 특성으로 Value는 List의 특성을 관리한다.
	//		HashMap, TreeMap, Properties
	
	// HashMap
	// --> Map의 Key는 Set의 특징을 띄고 있다.
	// --> Hash 단어가 포함된 컬렉션 사용시 내부에 저장되는 key는 equals와 hashcode가 오버라이딩
	// 	       되어있어야 한다.
	// --> String, Wrapper Class는 equals와 hashCode가 이미 오버라이딩 되어있어
	// 	   key로 많이 사용한다.
	
	public static void main(String[] args) {
		HashMap hmap = new HashMap();
		Map hmap2 = new HashMap();
		
		// map에 값을 저장할 때는
		// put() 메소드를 사용하는데, 
		// 키(key)와 값(value) 두가지 객체를 모두 저장해야한다.
		
		hmap.put("one", new Date());
		hmap.put("two", "안녕하세요");
		hmap.put("three", 12345); // 자동 Boxing처리된다.
		
		System.out.println("hmap : " + hmap);
		
		System.out.println("one : " + hmap.get("one"));
		System.out.println("three : " + hmap.get("three"));
		
		// 저장된 객체를 한 개씩 목록화하여 꺼내는방법
		// 1. keySet() 메소드를 활용
		Set keys = hmap.keySet();
		
		Iterator iter = keys.iterator();
		
		while(iter.hasNext()) {
			// Key 객체를 한개씩 꺼내오는 구문
			Object obj = iter.next();
			System.out.println(hmap.get(obj));
			
		}
		
		System.out.println("----------------------------");
		// 2. values() 메소드를 활용
		Collection values = hmap.values();
		Iterator iter2 = values.iterator();
		while(iter2.hasNext()) {
			System.out.println(iter2.next());
		}
		
		System.out.println("-----------------------------");
		// 3. Map.Entry 객체를 활용 : key와 value모두 출력하는 방법 
		Set entrySet = hmap.entrySet();
		Iterator iter3 = entrySet.iterator();
		
		while(iter3.hasNext()) {
			// key와 value 모두를 가지고있는 객체를 꺼내어 온다.
			Map.Entry entry = (Map.Entry)iter3.next();
			
			// key와 value를 각각 분리
			String key = (String)entry.getKey();
			Object value = entry.getValue();
			
			// key와 value를 출력
			System.out.println(key + " : " + value);
			
		}
	}
}
