package com.kh.generics;

import java.util.ArrayList;

public class TestGenerics1 {
	// 제네릭스란, 여러가지 자료형을 받을 수 있는 컬렉션에
	// 저장할 자료형을 한 가지로 제한함으로써 객체를 꺼내어 사용할 때
	// 객체에 대한 형변환을 생략하게 하는 기능이다.
	
	// Book --> Object(X)
	// Book --> Book(o)
	
	// 사용방법
	// 컬렉션클래스 변수명<제한할 자료형명>
	
	public static void main(String [] args) {
		// 책만 받기위한 리스트
		ArrayList<Book> list = new ArrayList<Book>();
		
		// 기본리스트
		ArrayList list2 = new ArrayList();
		
		list.add(new Book());
		
		// 리스트에 Book객체만 받도록 한정지었기 때문에
		// Book객체나 Book의 지식 객체만 저장할 수 있다.
		list2.add(new String("1234"));
		
		list2.add(new Book());
		list2.add(new String("12345"));
		
		// 향상된 for문
		for(Book bk : list) {
			// list안에 Book객체만 들어있기 때문에
			// Book형태로 굳이 형변환하지 않아도 된다.
			System.out.println(bk);
		}
		
		for(Object obj : list2) {
			if(obj instanceof Book) {
				Book bk = (Book)obj;
				System.out.println(bk);
			}
		}
	}
}
