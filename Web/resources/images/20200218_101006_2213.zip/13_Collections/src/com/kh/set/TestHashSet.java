package com.kh.set;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.kh.list.sort.Product;

public class TestHashSet {
	// Set :
	// 자료구조 유형 중 하나로
	// List와 대조되는 특성을 가지고있다.
	// Set은 순서가 유지되지 않으며, 중복을 허용하지 않는다.
	// 따라서 set을 하나의 집합이라고 표현하기도한다.
	// 종류는 크게 HashSet과 TreeSet, LinkedHashSet  
	
	public static void main(String[] args) {
		
		// HashSet 테스트
		HashSet hset = new HashSet();
		
		// 다형성 적용한 생성
//		Set hset2 = new HashSet();
//		Collection hset3 = new HashSet();
		
		hset.add("사과");
		hset.add(12345);
		hset.add(true);
		hset.add(12.4);
		hset.add('A');
		
		// 1. 저장 순서가 유지되지 않는다.
		// 2. toString이 재정의 되어있다.
		System.out.println("hset : " + hset);
		
		hset.add("사과");
		hset.add("키위");
		hset.add("사과");
		hset.add("포도");
		
		// 3. 중복을 허용하지 않는다.
		System.out.println("hset : " + hset);
		System.out.println("저장 개수 : " + hset.size());
		System.out.println("포함여부 확인 : " + hset.contains("사과"));
		
		System.out.println("---------------------");
		
		// 1. Set객체를 배열로 만들어서 하나씩 꺼내는 방법
		Object[] oArr = hset.toArray();
		
		for(Object obj : oArr) {
			System.out.println(obj);
		}
		
		System.out.println("-----------------");
		Iterator iter = hset.iterator();
		
		while(iter.hasNext()) {
			// 현재 요소를 꺼내어 오고 다음 요소로 이동한다.
			Object obj = iter.next();
			System.out.println(obj);
		}
		
		System.out.println("set이 비었나요? " + hset.isEmpty());
		
		// set자체를 통으로 지우자
		hset.clear();
		
		System.out.println("set이 비었나요? " + hset.isEmpty());
	
		hashSetEx();
	
	}
	
	public static void hashSetEx() {
		Set set = new HashSet();
		
		set.add(new Product("삼송",30000,0.1));
		set.add(new Product("사과",20000,0.3));
		set.add(new Product("샤옴",10000,0.2));
		set.add(new Product("삼송",30000,0.1));
		
		System.out.println(set);
		// ArrayList : equals()오라이딩해 이를 통해 값이 같은지 판단 
		// HashSet : Hash라는 이름이 들어간 클래스 들은 equals()와 hashCode()를 이용하여
		// 			  값이 같은지를 판단.
		// -> HashCode() : 데이터셋이나 해시테이블을 쓰기위해 생성된 하나의 인덱스(키)
		
		for(Object s : set) {
			System.out.println(s);
		}
		List list = new ArrayList();
		list.addAll(set);
		
		for(int i=0; i<list.size(); i++) {
			System.out.println(i + "번 인덱스 값 : " + list.get(i));
		}
		
		// Iterator 
		
		Iterator it = set.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
			
			
			
			
			
			
			
			
			
		}
	}
}






