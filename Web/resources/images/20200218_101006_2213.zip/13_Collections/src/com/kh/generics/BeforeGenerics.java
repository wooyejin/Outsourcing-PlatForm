package com.kh.generics;

import java.util.ArrayList;

public class BeforeGenerics {
	public static void main(String[] args) {
		// 컬렉션에는 여러가지 자료형을 담을 수 있다.
		// 컬렉션(list,set,map)
		
		ArrayList list = new ArrayList();
		list.add(new String("1234"));
		list.add(new Book());
		list.add(new Student());
		list.add(new Car());
		
		System.out.println("저장된 객체 수 : " + list.size());
		System.out.println("list : " + list);
		
		for(int i=0; i<list.size(); i++) {
			Object obj = list.get(i);
			if(obj instanceof Book) {
				System.out.println("책 객체 : " + obj);
			}
		}
		
		// 책, 자동차, 학생, 일반 문자열 각각 꺼내고 싶어요!
		for(int i=0; i<list.size(); i++) {
			Object obj = list.get(i);
			
			if(obj instanceof Book) {
				// 책에 대한 내용
			} else if(obj instanceof Car) {
				// 자동차에 대한 내용
			} else if(obj instanceof Student) {
				// 학생에 대한 내용
			}else if(obj instanceof String) {
				// 일반문자열에 대한 내용
			} else {
				// 다른 객체일경우 실행할 내용
			}
		}
		
	}
}

class Book {
	private String bNo;
	
	public Book() {}
	
	public Book(String bNo) {
		this.bNo = bNo;
	}

	@Override
	public String toString() {
		return "나는" + bNo + "입니다.";
	}
	
}

class Student{
	private String stuNo;
	
	public Student() {}
	
	public Student(String stuNo) {
		this.stuNo = stuNo;
	}

	@Override
	public String toString() {
		return "나는" + stuNo + "입니다.";
	}
}

class Car {
	private String model;
	
	public Car() {}
	
	public Car(String model) {
		this.model = model;
	}

	@Override
	public String toString() {
		return "나는" + model + "입니다.";
	}
	
	
}
